const firebaseConfig = {
    apiKey: "AIzaSyCwiZTNtw6oRVVUAdMSr_CSI0JDNF7y-zc",
    authDomain: "travelx-35de3.firebaseapp.com",
    projectId: "travelx-35de3",
    storageBucket: "travelx-35de3.appspot.com",
    messagingSenderId: "534855889561",
    appId: "1:534855889561:web:5de37eb68f0144224d7e08"
};


export default firebaseConfig;
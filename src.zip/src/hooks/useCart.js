import { useEffect, useState } from "react";
// import useAuth from "./useAuth.js";
import useFirebase from "./useFirebase.js";

const useCart = () => {
    const { user } = useFirebase();

    const { uid } = user;

    const [selectedPackage, setSelectedPackage] = useState([]);

    useEffect(() => {
        fetch(`http://localhost:5000/cart/${uid}`)
            .then((res) => res.json())
            .then((data) => {
                if (data.length) {
                    setSelectedPackage(data);
                }
            });
        setSelectedPackage([])
    }, [uid]);

    function addToCart(tour) {
        const isHave = selectedPackage.find(
            (selected) => selected._id === tour._id
        );
        delete tour._id;
        tour.uid = uid;
        tour.status = "pending";

        if (isHave) {
            alert("package has been selected!");
        } else {
            fetch("http://localhost:5000/package/add", {
                method: "post",
                headers: { "content-type": "application/json" },
                body: JSON.stringify(tour),
            })
                .then((res) => res.json())
                .then((data) => {
                    if (data.insertedId) {
                        const newSelection = [...selectedPackage, tour];
                        setSelectedPackage(newSelection);
                    }
                });
        }
    }

    function remove(id) {
        fetch(`http://localhost:5000/delete/${id}`, {
            method: "delete",
        })
            .then((res) => res.json())
            .then((data) => {
                if (data.deletedCount === 1) {
                    const selectAfterRemove = selectedPackage.filter(
                        (tour) => tour._id === id
                    );
                    setSelectedPackage(selectAfterRemove);
                } else {
                    alert("something went wrong!!");
                }
            });
    }

    return { setSelectedPackage, remove, addToCart, selectedPackage };
};

export default useCart;